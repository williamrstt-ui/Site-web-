(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,13181,e=>{"use strict";var t=e.i(43476),u=e.i(71645),i=e.i(75056),r=e.i(95393),a=e.i(90874),o=e.i(90072),n=e.i(93282);let l=e=>e===Object(e)&&!Array.isArray(e)&&"function"!=typeof e;function s(e,t){let i=(0,a.useThree)(e=>e.gl),r=(0,n.useLoader)(o.TextureLoader,l(e)?Object.values(e):e);return(0,u.useLayoutEffect)(()=>{null==t||t(r)},[t]),(0,u.useEffect)(()=>{if("initTexture"in i){let e=[];Array.isArray(r)?e=r:r instanceof o.Texture?e=[r]:l(r)&&(e=Object.values(r)),e.forEach(e=>{e instanceof o.Texture&&i.initTexture(e)})}},[i,r]),(0,u.useMemo)(()=>{if(!l(e))return r;{let t={},u=0;for(let i in e)t[i]=r[u++];return t}},[e,r])}s.preload=e=>n.useLoader.preload(o.TextureLoader,e),s.clear=e=>n.useLoader.clear(o.TextureLoader,e);let v=`
uniform float uVelocity;
uniform float uHover;
uniform vec2 uMouse;
uniform float uTime;
uniform vec2 uPlaneSize;

varying vec2 vUv;
varying float vWave;

#define PI 3.14159265

void main() {
  vUv = uv;
  vec3 p = position;

  // Courbure : les bords reculent quand la galerie file vite
  float bend = sin(uv.x * PI) * uVelocity;
  p.z -= bend * uPlaneSize.x * 0.12;
  // L\xe9g\xe8re ondulation verticale dans le sens du mouvement
  // (p.x/p.y sont en unit\xe9s locales, z est en pixels : le mesh n'est pas mis \xe0 l'\xe9chelle en z)
  p.y += sin(uv.x * PI) * uVelocity * 0.04;

  // Onde concentrique depuis le curseur au survol
  float d = distance(uv, uMouse);
  float wave = sin(d * 18.0 - uTime * 5.0) * exp(-d * 3.5) * uHover;
  p.z += wave * uPlaneSize.x * 0.035;
  vWave = wave;

  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
}
`,c=`
uniform sampler2D uTexture;
uniform vec2 uImageSize;
uniform vec2 uPlaneSize;
uniform float uHover;
uniform float uVelocity;
uniform float uTime;
uniform vec2 uMouse;
uniform float uOpacity;

varying vec2 vUv;
varying float vWave;

// \xc9quivalent GLSL de object-fit: cover
vec2 coverUv(vec2 uv, vec2 plane, vec2 image) {
  vec2 ratio = vec2(
    min((plane.x / plane.y) / (image.x / image.y), 1.0),
    min((plane.y / plane.x) / (image.y / image.x), 1.0)
  );
  return vec2(uv.x * ratio.x + (1.0 - ratio.x) * 0.5, uv.y * ratio.y + (1.0 - ratio.y) * 0.5);
}

void main() {
  vec2 uv = coverUv(vUv, uPlaneSize, uImageSize);

  // Zoom doux centr\xe9 au survol
  uv = (uv - 0.5) * (1.0 - 0.08 * uHover) + 0.5;

  // Ondulation liquide
  uv.x += sin(uv.y * 12.0 + uTime * 2.2) * 0.006 * uHover;
  uv.y += cos(uv.x * 10.0 + uTime * 1.8) * 0.006 * uHover;
  uv += vWave * 0.015;

  // Aberration chromatique horizontale li\xe9e \xe0 la vitesse
  float shift = uVelocity * 0.02 + uHover * 0.003;
  float r = texture2D(uTexture, uv + vec2(shift, 0.0)).r;
  float g = texture2D(uTexture, uv).g;
  float b = texture2D(uTexture, uv - vec2(shift, 0.0)).b;

  gl_FragColor = vec4(r, g, b, uOpacity);
  #include <colorspace_fragment>
}
`;function f(){let{camera:e,size:t}=(0,a.useThree)();return(0,u.useEffect)(()=>{e.position.set(0,0,800),e.fov=2*Math.atan(t.height/2/800)*180/Math.PI,e.near=1,e.far=3e3,e.updateProjectionMatrix()},[e,t]),null}function m({items:e,shared:t}){let{gl:i}=(0,a.useThree)(),n=(0,u.useRef)(null);return(0,r.useFrame)(()=>{t.canvasRect=i.domElement.getBoundingClientRect();let u=e[0]?.el;if(!u)return;let r=u.getBoundingClientRect().left,a=null===n.current?0:n.current-r;n.current=r;let l=o.MathUtils.clamp(a/60,-1,1);t.velocity+=(l-t.velocity)*.1},-1),null}function x({texture:e,item:i,shared:n}){let l=(0,u.useRef)(null),{size:s}=(0,a.useThree)(),f=(0,u.useMemo)(()=>{let t=e.image;return{uTexture:{value:e},uImageSize:{value:new o.Vector2(t.width,t.height)},uPlaneSize:{value:new o.Vector2(1,1)},uHover:{value:0},uMouse:{value:new o.Vector2(.5,.5)},uVelocity:{value:0},uTime:{value:0},uOpacity:{value:1}}},[e]);return(0,r.useFrame)((e,t)=>{let u=l.current,r=n.canvasRect;if(!u||!i.el||!r)return;let a=i.el.getBoundingClientRect();u.visible=a.right>r.left-200&&a.left<r.right+200,u.visible&&(u.scale.set(a.width,a.height,1),u.position.x=a.left-r.left+a.width/2-s.width/2,u.position.y=-(a.top-r.top+a.height/2)+s.height/2,f.uPlaneSize.value.set(a.width,a.height),f.uTime.value+=t,f.uHover.value+=(i.hover-f.uHover.value)*.08,f.uMouse.value.x+=(i.mouse.x-f.uMouse.value.x)*.1,f.uMouse.value.y+=(i.mouse.y-f.uMouse.value.y)*.1,f.uVelocity.value=n.velocity)}),(0,t.jsxs)("mesh",{ref:l,children:[(0,t.jsx)("planeGeometry",{args:[1,1,32,32]}),(0,t.jsx)("shaderMaterial",{vertexShader:v,fragmentShader:c,uniforms:f,transparent:!0})]})}function d({srcs:e,items:i,onReady:r}){let n=s(e),{gl:l}=(0,a.useThree)(),v=(0,u.useMemo)(()=>({velocity:0,canvasRect:null}),[]);return(0,u.useEffect)(()=>{n.forEach(e=>{e.colorSpace=o.SRGBColorSpace,e.anisotropy=Math.min(8,l.capabilities.getMaxAnisotropy()),e.needsUpdate=!0}),n.forEach(e=>l.initTexture(e)),r()},[n,l,r]),(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(m,{items:i,shared:v}),n.map((u,r)=>(0,t.jsx)(x,{texture:u,item:i[r],shared:v},e[r]))]})}e.s(["default",0,function({srcs:e,items:r,active:a,onReady:o}){return(0,t.jsxs)(i.Canvas,{style:{position:"absolute",inset:0,pointerEvents:"none"},dpr:[1,1.75],frameloop:a?"always":"never",gl:{antialias:!0,alpha:!0},"aria-hidden":!0,children:[(0,t.jsx)(f,{}),(0,t.jsx)(u.Suspense,{fallback:null,children:(0,t.jsx)(d,{srcs:e,items:r,onReady:o})})]})}],13181)},94344,function(e){e.n(e.i(13181))}]);